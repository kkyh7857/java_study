package Question3;

public class MP3Player {
	private String name; // �𵨸�
	private String color; // ����
	private boolean power; // ��������
		
	public MP3Player(String name, String color, boolean power) {
		this.name = name;
		this.color = color;
		this.power = power;
	}

	public void powerOnOff(boolean onOff) {
		
	}
	
	public void play(){
		
	}
	
	public void stop() {
	
	}
	
	public int remove(int number) {
		return number ;
	}
}
